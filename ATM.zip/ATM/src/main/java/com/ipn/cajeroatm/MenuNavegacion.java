/*
 @author Connor Urbano Mendoza
 */
package com.ipn.cajeroatm;

import javax.swing.JOptionPane;

public class MenuNavegacion {
    public void Mostrar_Menu_Navegacion()
    {   
        
        FuncionesDelATM Funcion=new FuncionesDelATM();
        CuentaATM Ct= new CuentaATM(181101,"Connor","Tlanepantla");
        //Variables de nocion
        String Opcion_switch="";
        String Indicador_de_Salida="1";
        //Variables de operacion
        //String Saldo="1500";
        float Var_SaldoNumerica;
        String c="";
        String c1="";
        int c2;
        
        c=Ct.getNombre();
        c1=Ct.getDireccion();
        c2=Ct.getID();
        
        Var_SaldoNumerica = (Ct.getSaldo());
        do
        {   
            //Menu de navegacion
            Opcion_switch=JOptionPane.showInputDialog(null,"            Menu principal del ATM\n\nEliga la opción de su preferencia:\n\n1.   "
            + "Ver Saldo.\n2.   Realizar Retiro.\n3.   Realizar Depósito.\n4.   Salir del cajero.\n\n","ATM: "+c+"       Direccion: "+c1+"       ID:"+c2,0);
            //Fin de conjunto de visualizacion del menu
            switch(Opcion_switch){
                case "1": 
                    Var_SaldoNumerica=Funcion.Ver_Saldo(Var_SaldoNumerica);
                break;
                case "2": 
                    Var_SaldoNumerica=Funcion.Hacer_Retiro(Var_SaldoNumerica);
                break;
                case "3": 
                    Var_SaldoNumerica=Funcion.Hacer_Deposito(Var_SaldoNumerica);
                break;
                case "4": 
                    Indicador_de_Salida="0";
                break;
            }
        }while(!Indicador_de_Salida.equals("0"));
    }
}

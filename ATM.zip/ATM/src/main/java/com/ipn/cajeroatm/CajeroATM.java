/*
@author Connor Urbano Mendoza
 */

package com.ipn.cajeroatm;

import javax.swing.JOptionPane;

public class CajeroATM 
{
    public static void main(String[] args) {
        
        MenuNavegacion Nav = new MenuNavegacion();
        Nav.Mostrar_Menu_Navegacion();
        System.out.println("El programa termino con éxito");
    }
}

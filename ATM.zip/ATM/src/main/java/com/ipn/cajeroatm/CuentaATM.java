/*
 @author Connor Urbano Mendoza
 */
package com.ipn.cajeroatm;

import javax.swing.JOptionPane;

public class CuentaATM {
    
    private int ID;
    private String nombre;
    private String direccion;
    private float saldo;
    
    public CuentaATM(){
        ID=0;
        nombre="";
        direccion="";
        saldo=1500.00f;
    }
    
    public CuentaATM(int id, String n,String d){
        ID=id;
        nombre=n;
        direccion=d;
        saldo=1500.00f;
        
    }
    public int getID() {
        return ID;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }
    public float getSaldo() {
        return saldo;
    }
}

/*
 @author Connor Urbano Mendoza
 */
package com.ipn.cajeroatm;

import javax.swing.JOptionPane;

public class FuncionesDelATM {
    public float Ver_Saldo(float Saldo){
        float SaldoAjustado;
        SaldoAjustado=Saldo;
        if(Saldo>=1000){
            JOptionPane.showMessageDialog(null,"Tu saldo actual es de:\n"+SaldoAjustado,"RESULTADO",JOptionPane.DEFAULT_OPTION);
        }
        else {
            SaldoAjustado=(Saldo-(30.5f));
            JOptionPane.showMessageDialog(null,"Tu saldo actual menos la comisión es de:\n"+SaldoAjustado,"RESULTADO",JOptionPane.DEFAULT_OPTION);
        }
        return SaldoAjustado;
    }
    
    public float Hacer_Retiro(float Saldo){
        String Bandera="1";
        float SaldoAjustado;
        float CantidadRetiro;
        float CondicionalRetiro;
        String Opcion="";
        
        if(Saldo>=1000){
            do{
                Opcion=JOptionPane.showInputDialog("2.   Ingrese la cantidad a retirar:\n\n");
                CondicionalRetiro = Float.parseFloat(Opcion);
                if(Opcion.contains("-") || Opcion.contains("+")){
                    JOptionPane.showMessageDialog(null,"No se aceptan carácteres especiales [-] o [+], intentelo de nuevo.\n","Warning",JOptionPane.DEFAULT_OPTION);
                }
                
                else if(CondicionalRetiro>Saldo){
                    JOptionPane.showMessageDialog(null,"No cuenta con fondos suficientes para realizar este retiro.\n","Warning",JOptionPane.DEFAULT_OPTION);
                }
                else{
                    Bandera="0";
                }
            }while(!Bandera.equals("0"));
            
            CantidadRetiro = Float.parseFloat(Opcion);
            SaldoAjustado = (Saldo-(CantidadRetiro));
            JOptionPane.showMessageDialog(null,"La transacción fue exitosa, se hizo un retiro por concepto de:\n\n"+CantidadRetiro,"Transaccion Completa",JOptionPane.DEFAULT_OPTION);
            return SaldoAjustado;
        }
        else {
            do{
                Opcion=JOptionPane.showInputDialog("2.   Ingrese la cantidad a retirar:\n\n");
                CondicionalRetiro = Float.parseFloat(Opcion);
                if(Opcion.contains("-") || Opcion.contains("+")){
                    JOptionPane.showMessageDialog(null,"No se aceptan carácteres especiales [-] o [+], intentelo de nuevo.\n","Warning",JOptionPane.DEFAULT_OPTION);
                }
                else if(CondicionalRetiro>Saldo){
                    JOptionPane.showMessageDialog(null,"No cuenta con fondos suficientes para realizar este retiro.\n","Warning",JOptionPane.DEFAULT_OPTION);
                }
                else{
                    Bandera="0";
                }
            }while(!Bandera.equals("0"));
            
            CantidadRetiro=Float.parseFloat(Opcion);
            SaldoAjustado=(Saldo-(CantidadRetiro));
            SaldoAjustado=(SaldoAjustado-(30.5f));
            JOptionPane.showMessageDialog(null,"La transacción fue exitosa, se hizo un retiro por concepto más comisión de:\n\n"+CantidadRetiro,"Transaccion Completa",JOptionPane.DEFAULT_OPTION);
            return SaldoAjustado;
        }
    }
    public float Hacer_Deposito(float Saldo){
        
            String Opcion="";
            String Bandera="1";
            float SaldoAjustado;
            float CantidadDeposito;
            try{
                do{
                    Opcion=JOptionPane.showInputDialog("3.   Ingrese la cantidad a depositar:\n\n");
                    if(Opcion.contains("-") || Opcion.contains("+")){
                        JOptionPane.showMessageDialog(null,"No se aceptan carácteres especiales [-] o [+], intentelo de nuevo.\n","Warning",JOptionPane.DEFAULT_OPTION);
                    }
                    else{
                        Bandera="0";
                    }
                }while(!Bandera.equals("0"));
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Aviso: Debido a la salida repentina, se le regresa al menu principal.\n","Warning",JOptionPane.DEFAULT_OPTION);
                return Saldo;
            }
            CantidadDeposito = Float.parseFloat(Opcion);
            SaldoAjustado=(Saldo+(CantidadDeposito));

            return SaldoAjustado;
        
    }
}

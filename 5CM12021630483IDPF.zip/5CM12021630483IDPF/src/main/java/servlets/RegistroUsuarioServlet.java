package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import config.Conexion;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RegistroUsuarioServlet", urlPatterns = {"/servlets/RegistroUsuarioServlet"})
public class RegistroUsuarioServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellidoP = request.getParameter("apellidoP");
        String apellidoM = request.getParameter("apellidoM");
        String edad = request.getParameter("edad");
        String materia = request.getParameter("materia");
        String grupo = request.getParameter("grupo");
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");
        System.out.println("contraseña "+password);
        Conexion conexion = new Conexion();
        Connection connection = conexion.getConection();
        PreparedStatement preparedStatement = null;

        try {
            String query = "INSERT INTO Usuarios (nombre, apellido_paterno, apellido_materno, edad, materia_imparte, grupo_dirige, username, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, apellidoP);
            preparedStatement.setString(3, apellidoM);
            preparedStatement.setString(4, edad);
            preparedStatement.setString(5, materia);
            preparedStatement.setString(6, grupo);
            preparedStatement.setString(7, usuario);
            preparedStatement.setString(8, password);

            int filasInsertadas = preparedStatement.executeUpdate();

            if (filasInsertadas > 0) {
                // Redireccionar a una página de éxito o mostrar un mensaje de éxito en la respuesta
                System.out.println("Exito");
                response.sendRedirect("/5CM12021630483IDPF");
            } else {
                // Las credenciales son incorrectas, agregar el mensaje de error como parámetro en la URL
                String errorMessage = "Datos de llenado no validos o ya registrados.";
                String redirectURL = "/5CM12021630483IDPF/?errorMessage=" + URLEncoder.encode(errorMessage, "UTF-8");
                response.sendRedirect(redirectURL); // Redireccionar a la página de inicio con el mensaje de error en la URL
            }
        } catch (SQLException e) {
            System.out.println("Fallo2");
            e.printStackTrace();
            // Redireccionar a una página de error o mostrar un mensaje de error en la respuesta
            response.sendRedirect("registro_error.html");
        } finally {
            // Cerrar conexiones y liberar recursos
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                // Manejar cualquier excepción al cerrar conexiones
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}

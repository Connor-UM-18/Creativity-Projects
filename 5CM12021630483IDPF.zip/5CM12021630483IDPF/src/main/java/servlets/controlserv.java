
package servlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Preguntas;
import modelo.preguntasDAO;
import modelo.Usuario;
import modelo.usuarioDAO;

@WebServlet(name = "controlserv", urlPatterns = {"/servlets/controlserv"})
public class controlserv extends HttpServlet {
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("entramos GET");
        preguntasDAO PreguntasDAO = new preguntasDAO();
        usuarioDAO UsuarioDAO = new usuarioDAO();
        String accion;
        RequestDispatcher dispatcher = null;
        accion = request.getParameter("accion");
        //System.out.println(accion);

        if (accion == null || accion.isEmpty()) {
            System.out.println("entramos ACCION NULL");
            List<Preguntas> listaPreguntas = PreguntasDAO.listarPreguntas();
            List<Usuario> listaUsuario = UsuarioDAO.listarUsuario();
            System.out.println("PASAMOS 1");

            // Agregar la lista de preguntas como atributo del request
            request.setAttribute("lista", listaPreguntas);
            // Obtener el primer usuario de la lista
            Usuario primerUsuario = listaUsuario.get(0);

            // Obtener los valores correspondientes del primer usuario
            String nombre = primerUsuario.getNombre();
            String apellidoM = primerUsuario.getApellidoM();
            String apellidoP = primerUsuario.getApellidoP();
            String materia = primerUsuario.getMateria();
            String grupo = primerUsuario.getGrupo();
            int ID_usuario=primerUsuario.getID_usuario();

            // Agregar los valores de las variables como atributos del request
            request.setAttribute("nombre", nombre);
            request.setAttribute("apellidoM", apellidoM);
            request.setAttribute("apellidoP", apellidoP);
            request.setAttribute("materia", materia);
            request.setAttribute("grupo", grupo);
            request.setAttribute("ID_usuario", ID_usuario);
            System.out.println("porto");
            
            dispatcher = request.getRequestDispatcher("../control.jsp");
            
        }else if (accion.equals("eliminar")) {
            System.out.println("entramos ACCION ELIMINAR");

            // Obtener el ID de la pregunta a eliminar
            String preguntaId = request.getParameter("id");

            // Validar si se proporcionó el ID de la pregunta
            if (preguntaId != null && !preguntaId.isEmpty()) {
                System.out.println("entramos ACCION ELIMINAR 2");
                // Lógica para eliminar la pregunta utilizando una sentencia SQL
                PreguntasDAO.eliminar(Integer.parseInt(preguntaId));
                List<Preguntas> listaPreguntas = PreguntasDAO.listarPreguntas();
                List<Usuario> listaUsuario = UsuarioDAO.listarUsuario();
                System.out.println("PASAMOS");

                // Agregar la lista de preguntas como atributo del request
                request.setAttribute("lista", listaPreguntas);
                System.out.println("LLENO ELIM");
                // Obtener el primer usuario de la lista
                Usuario primerUsuario = listaUsuario.get(0);

                // Obtener los valores correspondientes del primer usuario
                String nombre = primerUsuario.getNombre();
                String apellidoM = primerUsuario.getApellidoM();
                String apellidoP = primerUsuario.getApellidoP();
                String materia = primerUsuario.getMateria();
                String grupo = primerUsuario.getGrupo();
                int ID_usuario=primerUsuario.getID_usuario();

                // Agregar los valores de las variables como atributos del request
                request.setAttribute("nombre", nombre);
                request.setAttribute("apellidoM", apellidoM);
                request.setAttribute("apellidoP", apellidoP);
                request.setAttribute("materia", materia);
                request.setAttribute("grupo", grupo);
                request.setAttribute("ID_usuario", ID_usuario);
                System.out.println("guerrero");
                    
                dispatcher = request.getRequestDispatcher("/control.jsp?idUsuario=" + ID_usuario);
            }

            // Resto del código correspondiente cuando la acción es "eliminar"

        }
        System.out.println("DISPATCHER");
        dispatcher.forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("entramos POST");
        doGet(request,response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

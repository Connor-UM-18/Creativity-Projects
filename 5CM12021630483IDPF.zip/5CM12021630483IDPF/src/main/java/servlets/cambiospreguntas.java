
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Preguntas;
import modelo.preguntasDAO;

@WebServlet(name = "cambiospreguntas", urlPatterns = {"/servlets/cambiospreguntas"})
public class cambiospreguntas extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los parámetros del formulario
        System.out.println("mor ");
        System.out.println("id1 "+request.getParameter("id"));
        System.out.println("id_usuario1 "+request.getParameter("id_Usuario"));
        int id = Integer.parseInt(request.getParameter("id"));
        int id_usuario = Integer.parseInt(request.getParameter("id_Usuario"));
        String pregunta = request.getParameter("pregunta");
        String respuesta = request.getParameter("respuesta");
        System.out.println("id "+id);
        System.out.println("id_usuario "+id_usuario);
        System.out.println("pregunta "+pregunta);
        System.out.println("respuesta "+respuesta);
        // Crear un objeto Preguntas con los datos recibidos
        Preguntas preguntaObj = new Preguntas(id, id_usuario, pregunta, respuesta);

        // Actualizar la pregunta en la base de datos
       preguntasDAO PreguntasDAO = new preguntasDAO();
        boolean actualizado = PreguntasDAO.actualizar(preguntaObj);

        if (actualizado) {
            // Redireccionar a la página de éxito
            String url = "controlserv?idUsuario=" + id_usuario;
            response.sendRedirect(url);
        } else {
            // Mostrar un mensaje de error
            response.getWriter().println("Error al actualizar la pregunta.");
        }
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

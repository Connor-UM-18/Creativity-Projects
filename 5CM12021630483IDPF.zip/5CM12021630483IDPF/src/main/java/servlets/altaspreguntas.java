package servlets;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Preguntas;
import modelo.preguntasDAO;

@WebServlet(name = "altaspreguntas", urlPatterns = {"/servlets/altaspreguntas"})
public class altaspreguntas extends HttpServlet {
    private preguntasDAO preguntasDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        preguntasDAO = new preguntasDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Entramos al registro guardar");
        // Obtener los valores del formulario
        String idUsuario = request.getParameter("idUsuario");
        String pregunta = request.getParameter("pregunta");
        String respuesta = request.getParameter("respuesta");
        
        // Crear un objeto Preguntas con los valores obtenidos
        Preguntas preguntas = new Preguntas(0, Integer.parseInt(idUsuario), pregunta, respuesta);
        
        // Llamar al método insertar de preguntasDAO
        boolean exito = preguntasDAO.insertar(preguntas);
        
        if (exito) {
            // Redirigir a la página de éxito o a cualquier otra página deseada
            String url = "controlserv?idUsuario=" + idUsuario;
            response.sendRedirect(url);
        }
         else {
            // Redirigir a la página de error o mostrar un mensaje de error en la misma página
            response.sendRedirect("error.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("entramos POST");
        doGet(request,response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}


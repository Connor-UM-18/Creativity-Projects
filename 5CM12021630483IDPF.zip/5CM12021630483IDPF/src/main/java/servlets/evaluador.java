package servlets;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Preguntas;
import modelo.Usuario;
import modelo.preguntasDAO;
import modelo.usuarioDAO;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;

@WebServlet(name = "evaluador", urlPatterns = {"/servlets/evaluador"})
public class evaluador extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        usuarioDAO UsuarioDAO = new usuarioDAO();
        List<Usuario> listaUsuario = UsuarioDAO.listarUsuario();
        // Obtener el primer usuario de la lista
        Usuario primerUsuario = listaUsuario.get(0);
        // Obtener la lista de preguntas del preguntasDAO
        preguntasDAO PreguntasDAO = new preguntasDAO();
        List<Preguntas> listaPreguntas = PreguntasDAO.listarPreguntas();
        ArrayList<String> preguntas = new ArrayList<>();
        // Obtener el número total de preguntas
        int totalPreguntas = listaPreguntas.size();
        // Obtener los valores correspondientes del primer usuario
        String nombre = primerUsuario.getNombre();
        String apellidoM = primerUsuario.getApellidoM();
        String apellidoP = primerUsuario.getApellidoP();
        String materia = primerUsuario.getMateria();
        String grupo = primerUsuario.getGrupo();
        // Agregar los valores de las variables como atributos del request
        request.setAttribute("nombre", nombre);
        request.setAttribute("apellidoM", apellidoM);
        request.setAttribute("apellidoP", apellidoP);
        request.setAttribute("materia", materia);
        request.setAttribute("grupo", grupo);
        // Crear una lista para almacenar las respuestas del usuario
        List<String> respuestas = new ArrayList<>();
        
        // Recorrer las respuestas enviadas desde el formulario
        for (int i = 1; i <= totalPreguntas; i++) {
            String respuesta = request.getParameter("respuesta" + i);
            System.out.println("respuestaUsuario " + respuesta);
            respuestas.add(respuesta);
        }

        // Crear una lista para almacenar las respuestas correctas
        List<String> respuestasCorrectas = new ArrayList<>();

        // Recorrer las preguntas y obtener las respuestas correctas
        for (Preguntas pregunta : listaPreguntas) {
            preguntas.add(pregunta.getPregunta());
            respuestasCorrectas.add(pregunta.getRespuesta());
            System.out.println("Pregunta: " + pregunta.getPregunta());
            System.out.println("Respuesta correcta: " + pregunta.getRespuesta());
        }
        
        // Guardar las preguntas y respuestas en un archivo de texto
        String rutaArchivo = "C:\\Users\\soyco\\OneDrive\\Documents\\NetBeansProjects\\5CM12021630483IDPF\\src\\main\\webapp\\recursos\\listas.txt";
        limpiarArchivo(rutaArchivo);
        actualizarListasRespuestas();
        int bandera = 0;
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            // Escribir el contenido de las listas en el archivo
            for (String pregunta : preguntas) {
                if (bandera == 0) {
                    writer.write(pregunta);
                    bandera = 1;
                } else {
                    writer.write("," + pregunta);
                }
            }
            bandera = 0;
            writer.write("\n");
            for (String respuesta : respuestas) {
                if (bandera == 0) {
                    writer.write(respuesta);
                    bandera = 1;
                } else {
                    writer.write("," + respuesta);
                }
            }
            bandera = 0;
            writer.write("\n");
            for (String respuestaCorrecta : respuestasCorrectas) {
                if (bandera == 0) {
                    writer.write(respuestaCorrecta);
                    bandera = 1;
                } else {
                    writer.write("," + respuestaCorrecta);
                }
            }

            // Guardar los cambios en el archivo
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //actualizarListasRespuestas();
        

        // Llamar al script Python para evaluar las respuestas
        List<String> listaEvaluacionPython = new ArrayList<>();
        System.out.println("Entramos al interprete");

        // Ruta del archivo evaluador.py
        String rutaArchivoPython = "C:\\Users\\soyco\\OneDrive\\Documents\\NetBeansProjects\\5CM12021630483IDPF\\src\\main\\webapp\\recursos\\evaluador.py";

        // Comando para ejecutar Python y pasarle el archivo evaluador.py como argumento
        String comandoPython = "C:\\Windows\\py.exe";
        String[] comando = {comandoPython, rutaArchivoPython};

        // Crear el proceso para ejecutar el comando
        ProcessBuilder processBuilder = new ProcessBuilder(comando);
        Process proceso = processBuilder.start();
        
        String rutaArchivo2 = "C:\\Users\\soyco\\OneDrive\\Documents\\NetBeansProjects\\5CM12021630483IDPF\\src\\main\\webapp\\recursos\\respuesta.txt";
        actualizarListasRespuestas();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo2))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                listaEvaluacionPython.add(linea);
            }
        }
        // Imprimimos listaEvaluacionPython
        System.out.println("Imprimimos listaEvaluacionPython\n");
        for (String elemento : listaEvaluacionPython) {
            System.out.println(elemento);
        }
        System.out.println("FIN listaEvaluacionPython\n");
        System.out.println("Imprimimos Preg\n");
        for (String ELEMENTO : preguntas) {
            System.out.println(ELEMENTO);
        }
        System.out.println("FIN Preg\n");
        System.out.println("Imprimimos respuestas\n");
        for (String ELEMENTO : respuestas) {
            System.out.println(ELEMENTO);
        }
        System.out.println("FIN respuestas\n");
        System.out.println("Imprimimos respuestas Correctas\n");
        for (String ELEMENTO : respuestasCorrectas) {
            System.out.println(ELEMENTO);
        }
        System.out.println("FIN Correctas\n");
        int ID_usuario = primerUsuario.getID_usuario();
        // Aquí puedes hacer lo que necesites con la lista de evaluación obtenida
        
        // Guardar las listas como atributos en el objeto request
        request.setAttribute("listaEvaluacionPython", listaEvaluacionPython);
        request.setAttribute("Preg", preguntas);
        request.setAttribute("Respuestas_usuario", respuestas);
        request.setAttribute("Respuestas_correcta", respuestasCorrectas);
        request.setAttribute("ID_usuario", ID_usuario);
        
        RequestDispatcher dispatcher = null;
        dispatcher = request.getRequestDispatcher("/resultado.jsp?idUsuario=" + ID_usuario);
        //response.sendRedirect("../resultado.jsp");
        limpiarArchivo(rutaArchivo2);
        System.out.println("DISPATCHER");
        dispatcher.forward(request, response);
    }
    
    private void actualizarListasRespuestas() {
        try {
            // Obtener la instancia de Desktop
            Desktop desktop = Desktop.getDesktop();
            // Pausa para asegurarnos de que los archivos estén completamente cargados
            Thread.sleep(4000);
            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
    
    private void limpiarArchivo(String rutaArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo, false))) {
            // Sobrescribir el archivo vaciándolo
            writer.write("");
        } catch (IOException e) {
        }
    }
}

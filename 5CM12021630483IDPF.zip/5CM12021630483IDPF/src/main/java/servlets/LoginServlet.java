package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import config.Conexion;
import java.net.URLEncoder;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/servlets/LoginServlet"}, initParams = {
    @WebInitParam(name = "LoginS", value = "Value")})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("id");
        String password = request.getParameter("password");
        System.out.println(username);
        System.out.println(password);
        Conexion conexion = new Conexion();
        Connection connection = conexion.getConection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            System.out.println("SELECT");
            String query = "SELECT * FROM Usuarios WHERE username = ? AND contraseña = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement.executeQuery();
            System.out.println(resultSet);
            if (resultSet.next()) {
                // Las credenciales son correctas, redirigir al usuario a la página deseada
                System.out.println("OPCION 1");
                // Consulta para obtener el ID_usuario basado en el username
                String queryIdUsuario = "SELECT ID_usuario FROM Usuarios WHERE username = ?";
                PreparedStatement preparedStatementIdUsuario = connection.prepareStatement(queryIdUsuario);
                preparedStatementIdUsuario.setString(1, username);
                ResultSet resultSetIdUsuario = preparedStatementIdUsuario.executeQuery();

                if (resultSetIdUsuario.next()) {
                    System.out.println("Exito a vista");
                    int idUsuario = resultSetIdUsuario.getInt("ID_usuario");
                    System.out.println("ID "+idUsuario);
                    // Almacenar el ID_usuario en la sesión
                    HttpSession session = request.getSession();
                    session.setAttribute("idUsuario", idUsuario);

                    // Redirigir al usuario a la página "vista.html" con el ID de usuario como parámetro en la URL
                    response.sendRedirect("/5CM12021630483IDPF/vista.jsp?idUsuario=" + idUsuario);
                } else {
                     System.out.println("Error");
                    // El username no se encontró en la base de datos
                    // Redireccionar a una página de error o mostrar un mensaje de error en la respuesta
                    response.sendRedirect("error.html");
                }

                // Cerrar el ResultSet y el PreparedStatement
                resultSetIdUsuario.close();
                preparedStatementIdUsuario.close();
            } else {
                // Las credenciales son incorrectas, agregar el mensaje de error como parámetro en la URL
                String errorMessage = "Datos de llenado incorrectos o no registrados";
                String redirectURL = "/5CM12021630483IDPF/?errorMessage=" + URLEncoder.encode(errorMessage, "UTF-8");
                response.sendRedirect(redirectURL); // Redireccionar a la página de inicio con el mensaje de error en la URL
            }



        } catch (Exception e) {
            // Manejar cualquier excepción
        } finally {
            // Cerrar conexiones y liberar recursos
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                // Manejar cualquier excepción al cerrar conexiones
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}


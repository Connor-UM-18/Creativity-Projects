
package modelo;

public class Preguntas {
    private int id, id_usuario;
    private String pregunta, respuesta;
    
    public Preguntas(int id, int id_usuario, String pregunta, String respuesta){
        this.id=id;
        this.id_usuario=id_usuario;
        this.pregunta=pregunta;
        this.respuesta=respuesta;
        //System.out.println("preg "+id);
        //System.out.println("preg "+id_usuario);
        //System.out.println("preg "+pregunta);
        //System.out.println("preg "+respuesta);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
    @Override
    public String toString() {
        return "Pregunta [id=" + id + ", id_usuario=" + id_usuario + ", pregunta=" + pregunta + ", respuesta=" + respuesta + "]";
    }
}

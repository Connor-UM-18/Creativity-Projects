
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class usuarioDAO {
    Connection conexion;
    public usuarioDAO(){
        Conexion con = new Conexion();
        conexion = con.getConection();
    }
    public List<Usuario> listarUsuario(){
        PreparedStatement ps;
        ResultSet rs;
        List<Usuario> lista = new ArrayList<>();
        try{
            ps = conexion.prepareStatement("SELECT nombre,apellido_materno,apellido_paterno,materia_imparte,grupo_dirige,ID_usuario FROM usuarios");
            rs = ps.executeQuery();
            while(rs.next()){
                String nombre = rs.getString("nombre");
                String apellidoP = rs.getString("apellido_paterno");
                String apellidoM = rs.getString("apellido_materno");
                String materia = rs.getString("materia_imparte");
                String grupo = rs.getString("grupo_dirige");
                int ID_usuario=rs.getInt("ID_usuario");
                Usuario usuario = new Usuario( nombre,  apellidoP,  apellidoM,  materia, grupo,ID_usuario);
                lista.add(usuario);
            }
            // Imprime el contenido de la lista
            //for (Usuario usuario : lista) {
                //System.out.println("for 2");
                //System.out.println(usuario); // Suponiendo que Preguntas tiene una implementación adecuada del método toString()
            //}
            return lista;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
    }
    
    
}

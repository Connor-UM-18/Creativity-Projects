
package modelo;

public class Usuario {
    private int ID_usuario;
    private String nombre, apellidoP,apellidoM,materia, grupo;
    
    public Usuario(String nombre, String apellidoP, String apellidoM, String materia, String grupo,int ID_usuario){
        this.nombre=nombre;
        this.apellidoP=apellidoP;
        this.apellidoM=apellidoM;
        this.materia=materia;
        this.grupo=grupo;
        this.ID_usuario=ID_usuario;
        //System.out.println("usu "+nombre);
        //System.out.println("usu "+apellidoP);
        //System.out.println("usu "+apellidoM);
        //System.out.println("usu "+materia);
        //System.out.println("usu "+grupo);
    }

    public int getID_usuario() {
        return ID_usuario;
    }

    public void setID_usuario(int ID_usuario) {
        this.ID_usuario = ID_usuario;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }
    @Override
    public String toString() {
        return "Usuario [nombre=" + nombre + ", apellidoP=" + apellidoP + ", apellidoM=" + apellidoM + ", materia=" + materia + ", grupo=" + grupo + ", ID_usuario=" + ID_usuario + "]";
    }
    
}

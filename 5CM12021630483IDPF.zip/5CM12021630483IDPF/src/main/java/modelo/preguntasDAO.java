
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class preguntasDAO {
    Connection conexion;
    public preguntasDAO(){
        Conexion con = new Conexion();
        conexion = con.getConection();
    }
    public List<Preguntas> listarPreguntas(){
        PreparedStatement ps;
        ResultSet rs;
        List<Preguntas> lista = new ArrayList<>();
        try{
            ps = conexion.prepareStatement("SELECT id,id_usuario,pregunta,respuesta FROM preguntas");
            rs = ps.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                int id_usuario = rs.getInt("id_usuario");
                String preguntaX = rs.getString("pregunta");
                String respuesta = rs.getString("respuesta");
                //System.out.println(id);
                //System.out.println(id_usuario);
                //System.out.println(preguntaX);
                //System.out.println(respuesta);
                Preguntas pregunta = new Preguntas(id, id_usuario,preguntaX,respuesta);
                //System.out.println("Socrates");
                lista.add(pregunta);
            }
            // Imprime el contenido de la lista
            //for (Preguntas pregunta : lista) {
              //  System.out.println("for 1");
                //System.out.println(pregunta); // Suponiendo que Preguntas tiene una implementación adecuada del método toString()
            //}
            return lista;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
            
        }
    }
    
    public List<Preguntas> mostrarPregunta(int idusuario){
        PreparedStatement ps;
        ResultSet rs;
        Preguntas pregunta=null;
        try{
            ps = conexion.prepareStatement("SELECT id,id_usuario,pregunta,respuesta FROM preguntas WHERE id_usuario=?");
            ps.setInt(1, idusuario);
            rs = ps.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("id");
                int id_usuario = rs.getInt("id_usuario");
                String preguntaX = rs.getString("pregunta");
                String respuesta = rs.getString("respuesta");
                pregunta = new Preguntas(id, id_usuario,preguntaX,respuesta);
                
            }
            return (List<Preguntas>) pregunta;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
            
        }
    }
    
    
    public boolean insertar(Preguntas pregunta){
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("INSERT INTO preguntas (id_usuario,pregunta,respuesta) VALUES (?,?,?)");
            ps.setInt(1, pregunta.getId_usuario());
            ps.setString(2, pregunta.getPregunta());
            ps.setString(3, pregunta.getRespuesta());
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public boolean actualizar(Preguntas pregunta){
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("UPDATE preguntas SET pregunta=?,respuesta=? WHERE id=?");
            ps.setString(1, pregunta.getPregunta());
            ps.setString(2, pregunta.getRespuesta());
            ps.setInt(3, pregunta.getId());
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public boolean eliminar(int id){
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("DELETE FROM preguntas WHERE id=?");
            ps.setInt(1, id);
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
}

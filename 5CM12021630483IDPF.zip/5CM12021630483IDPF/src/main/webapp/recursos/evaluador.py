import spacy
import os

nlp = spacy.load('es_core_news_sm')

directorio_actual = os.path.dirname(os.path.abspath(__file__))
#print(directorio_actual)
lista_file = os.path.join(directorio_actual, 'listas.txt')
#print(lista_file)

lista_file2 = os.path.join(directorio_actual, 'respuesta.txt')
print(lista_file2)

# Leer las listas desde el archivo listas.txt
#lista_file = "C:\\Users\\soyco\\OneDrive\\Documents\\NetBeansProjects\\5CM12021630483IDPF\\src\\main\\webapp\\recursos\\listas.txt"
#lista_file2 = "C:\\Users\\soyco\\OneDrive\\Documents\\NetBeansProjects\\5CM12021630483IDPF\\src\\main\\webapp\\recursos\\respuesta.txt"
with open(lista_file, 'r') as file:
    lines = file.readlines()
    preguntas = lines[0].strip().split(',')
    respuestas_usuario = lines[1].strip().split(',')
    respuestas_correctas = lines[2].strip().split(',')

# Función para evaluar una pregunta y su respuesta
def evaluar_pregunta(pregunta, respuesta):
    doc = nlp(pregunta)
    for token in doc:
        if token.text.lower() in respuesta.lower():
            return True
    return False

evaluador=[]
# Iterar sobre las preguntas y respuestas
with open(lista_file2, 'w') as file2:
    for i in range(len(preguntas)):
        pregunta = preguntas[i]
        respuesta_usuario = respuestas_usuario[i]
        respuesta_correcta = respuestas_correctas[i]
        
        #print(pregunta)
        #print("Tu respuesta:", respuesta_usuario)
        
        if evaluar_pregunta(respuesta_usuario, respuesta_correcta):
            file2.write("!Tu respuesta es correcta!")
        else:
            file2.write("Incorrecta. La respuesta correcta es: " + respuesta_correcta)
        file2.write("\n")

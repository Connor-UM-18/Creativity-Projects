/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mod;

/**
 *
 * @author soyco
 */
public class Equipos {
    private int id;
    private String Nombre, Ciudad, Pais;
    
    public Equipos(int id, String Nombre, String Ciudad, String Pais){
        this.id=id;
        this.Nombre = Nombre;
        this.Ciudad =Ciudad;
        this.Pais=Pais;
    }
    public String toString() {
        return "Equipo #" + id + ": " + Nombre + " de " + Ciudad + ", " + Pais;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCiudad() {
        return Ciudad;
    }

    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }

    public String getPais() {
        return Pais;
    }

    public void setPais(String Pais) {
        this.Pais = Pais;
    }
}

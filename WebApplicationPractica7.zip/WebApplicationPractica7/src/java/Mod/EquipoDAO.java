/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mod;

import config.Conection;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author soyco
 */
public class EquipoDAO {
    Connection conection;
    
    public EquipoDAO() {
        Conection con = new Conection();
        conection = con.getConection();
    }
    public List<Equipos> listarEquipos(){
        PreparedStatement PS;
        ResultSet RS;
        List<Equipos> lista = new ArrayList<>();
        try{
            PS = conection.prepareStatement("SELECT idEquipo, Nombre, Ciudad, Pais FROM equipos");
            RS = PS.executeQuery();
            while(RS.next()){
                int id = RS.getInt("idEquipo");
                String Nombre =RS.getString("Nombre");
                String Ciudad =RS.getString("Ciudad");
                String Pais =RS.getString("Pais");
                //System.out.println(id);
                //System.out.println(Nombre);
                //System.out.println(Ciudad);
                //System.out.println(Pais);
                Equipos equipo = new Equipos(id,Nombre,Ciudad,Pais);
                lista.add(equipo);
                /*System.out.println(Pais);
                System.out.println(equipo.toString());
                for (Equipos ELE : lista) {
                    System.out.println("ID: " + ELE.getId());
                    System.out.println("Nombre: " + ELE.getNombre());
                    System.out.println("Ciudad: " + ELE.getCiudad());
                    System.out.println("País: " + ELE.getPais());
                }
                */
            }
            return lista;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
    }
    
    public Equipos mostrarEquipos(int _id){
        PreparedStatement PS;
        ResultSet RS;
        Equipos equipo =null;
        try{
            PS = conection.prepareStatement("SELECT idEquipo, Nombre, Ciudad, Pais FROM futbol WHERE idEquipo=?");
            PS.setInt(1, _id);
            RS = PS.executeQuery();
            while(RS.next()){
                int id = RS.getInt("idEquipo");
                String Nombre =RS.getString("Nombre");
                String Ciudad =RS.getString("Ciudad");
                String Pais =RS.getString("Pais");
                
                equipo = new Equipos(id,Nombre,Ciudad,Pais);
            }
            return equipo;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
    }
    
    public boolean insertar(Equipos equipo){
        PreparedStatement PS;
        try{
            PS = conection.prepareStatement("INSERT INTO equipos (Nombre,Ciudad,Pais) VALUES (?,?,?)");
            
            PS.setString(1, equipo.getNombre());
            PS.setString(2, equipo.getCiudad());
            PS.setString(3, equipo.getPais());
            PS.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public boolean cambio(Equipos equipo){
        PreparedStatement PS;
        try{
            PS = conection.prepareStatement("UPDATE equipos SET Nombre=?,Ciudad=?,Pais=? WHERE idEquipo=?");
            
            PS.setString(1, equipo.getNombre());
            PS.setString(2, equipo.getCiudad());
            PS.setString(3, equipo.getPais());
            PS.setInt(4, equipo.getId());
            PS.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public boolean eliminar(int _id){
        PreparedStatement PS;
        try{
            PS = conection.prepareStatement("DELETE FROM equipos WHERE idEquipo=?");
            PS.setInt(1,_id);
            PS.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
}

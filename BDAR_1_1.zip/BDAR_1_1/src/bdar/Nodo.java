/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bdar;



/**
 *
 * @author soyco
 */
public class Nodo {
    String NomT;
    int IDTabla;
    double CoordT;
    Nodo siguiente;
    String DatoStr;//contiene
    int DatoInt;
    float Datoflt;
    


    public Nodo(int IDTabla,double CoordT,String DatoStr,int DatoInt,float Datoflt,String RNomT){
        this.NomT=RNomT;
        this.IDTabla=IDTabla;
        this.CoordT=CoordT;
        this.DatoStr=DatoStr;
        this.DatoInt=DatoInt;
        this.Datoflt=Datoflt;
        siguiente=null;
    }
    public Nodo(int IDTabla,double CoordT,String DatoStr,int DatoInt,float Datoflt,String RNomT,Nodo sig){
        this.NomT=RNomT;
        this.IDTabla=IDTabla;
        this.CoordT=CoordT;
        this.DatoStr=DatoStr;
        this.DatoInt=DatoInt;
        this.Datoflt=Datoflt;
        this.siguiente=sig;
    }

}


package bdar;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author soyco
 */
public interface ILista {
    public void insertar(int IDTabla,double CoordT,String DatoStr,int DatoInt,float Datoflt,String RNomT);
    public void insertarAp(Nodo actual);
    public boolean eliminar(int IDTabla,double CoordT,String DatoStr,int DatoInt,float Datoflt,String RNomT);
    public int eliminar();
    public boolean buscarIDT (int IDTabla);
    public boolean buscarCoordT (double CoordT);
    public boolean buscarDatoStr (String DatoStr);
    public boolean buscarDatoInt (int DatoInt);
    public boolean buscarDatoflt (float Datoflt);
    public Nodo buscarIDTNod  (int IDTabla);
    public Nodo buscarCoordTNod  (double CoordT);
    public Nodo buscarDatoStrNod  (String DatoStr);
    public Nodo buscarDatoIntNod  (int DatoInt);
    public Nodo buscarDatofltNod  (float Datoflt);
    public String recorrer();
    public boolean vacia();
    public int tamaño();
    
}

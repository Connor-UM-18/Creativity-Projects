/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bdar;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
/**
 */
public class interfazTablas extends javax.swing.JFrame {
    Lista aplicar =new Lista();
    Nodo actual;
    double CoordT;
    String DatoStr;//contiene
    String NomT;//contiene
    int DatoInt;
    float Datoflt;
    
    public interfazTablas(String nombreTabla){
        //super("Mi TABLA");
        //DefaultTableModel modelo=new DefaultTableModel();
        //System.out.println(this.actual.IDTabla);
        //modelo.addColumn(modelo);
        //initComponents();
        this.NomT=nombreTabla;
    }
    
}


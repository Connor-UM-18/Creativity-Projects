/*
@author Connor Urbano Mendoza
 */

package bdar;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class BDAR extends JFrame{
    Lista aplicar =new Lista();
    //interfazTablas Nav2 = new interfazTablas();
    //Lista usar = Lista();
   
    public int ArrayTamañosT[]= new int[19];//Array de tamaños de las Tablas a capturar.
    public int CantTablas;//Cantidad de tablas que se generaron.
    
    public BDAR(){
        
        //SubmenuDeCaptura Nav = new SubmenuDeCaptura();
        //Variables
        String Opcion_switch="";//Variable de navegacion
        String Indicador_de_Salida="1";//Variable de Salida
        
        //Ciclo para el Menu de navegacion
        do
        {   
            
            Opcion_switch = JOptionPane.showInputDialog(null,"            Menu principal de la BD\n\nEliga la opción de su preferencia:\n\n1.   "
            + "Capturar BD.\n2.   Realizar Operadores Relacionales.\n3.   Salir del Programa.\n\n","BDAAR Equipo: 4",1);
            //Fin de conjunto de visualizacion del menu
            switch(Opcion_switch){
                case "1": 
                    if("1"=="1"){
                        //Nav.Mostrar_SubMenu(CantTablas,ArrayTamañosT,(this.actual));--------Submenu que mandaba a llamar al submenu de captura.
                        //Variables para el submenu
                        String Opcion_switch2="";//Variable de navegacion
                        String Indicador_de_Salida2="1";//Variable de Salida
                        //Metodos Nav = new Metodos();
                        //interfazT Nav2 = new interfazT();
                        //Ciclo para el Menu de navegacion
                        do
                        {   
                            Opcion_switch2 = JOptionPane.showInputDialog(null,"            Submenu Prinicpal de Captura de datos\n\nEliga la opción de su preferencia:\n\n1.   "
                            + "Crear Tablas.\n2.   Visualizar tablas.\n3.   Regresar al menu.\n\n","BDAAR Equipo: 4",1);
                            //Fin de conjunto de visualizacion del menu
                            switch(Opcion_switch2){
                                case "1": 
                                    if("1"=="1"){
                                        //Nav.crearTablas(CantTablas,ArrayTamañosT,actual);--menu que mandaba a llamar a los metodos.
                                        //Metodos Nav = new Metodos();
                                        //Variables.
                                        String Bandera="";//Variable de confirmacion.
                                        String R_confirmacion="";//Variable bandera.
                                        String Respuesta_Hor="";//Variable para el tamaño horizontal de la matriz.
                                        String filas="";//variable del numero de filas que tendra la tabla sin contar los atributos.
                                        String RCT="";
                                        String RNomT="";//Respuesta del nombre de la tabla i;
                                        int PosicionArrT=0;
                                        //int ContdeT;//Contador que nos indica en que Tabla vamos.

                                        //Se pide el tamaño de la matriz de los datos. 
                                        RCT=JOptionPane.showInputDialog(null," Por favor, ingrese el número de tablas que requerira su BD. \n\n","BDAAR Equipo: 4",1);
                                        CantTablas = Integer.parseInt(RCT);//Estos parset pasan las respuiestas que son string a enteros

                                        //Ciclo que dura la cantidad de tablas que se hayan creado
                                        for(int i=0; i <CantTablas;i++){
                                            //Se pide El nombre de tabla 1.
                                            RNomT=JOptionPane.showInputDialog(null,"Para TABLA No."+(i+1)+"\n\nPor favor, ingrese el nombre con el que identificaremos la tabla\n"
                                                + "\n","BDAAR Equipo: 4",1);
                                            
                                            //Se pide col.
                                            do{
                                                Respuesta_Hor=JOptionPane.showInputDialog(null,"Para TABLA No."+(i+1)+"\n\nPor favor, ingrese el número de atributos que tendra su tabla, por el momento solo\nse pueden "
                                                + "generar como máximo 6 atributos. \n","BDAAR Equipo: 4",1);
                                                R_confirmacion=JOptionPane.showInputDialog(null," Número de Atributos ingresados: " +Respuesta_Hor +" atributos."
                                                + "\n\nPor favor, confirme el numero de atributos. \n","BDAAR Equipo: 4",1);//confirmacion

                                                if (Respuesta_Hor.equals(R_confirmacion)){
                                                    Bandera="1";
                                                }else{
                                                    JOptionPane.showMessageDialog(null,"Los atributos ingresados no coinciden en la confirmación.\n\n"
                                                    +"Ingrese los datos nuevamente.", "Error", JOptionPane.INFORMATION_MESSAGE);
                                                    Bandera="0";
                                                }
                                            }while(Bandera == "0");
                                            //Se pide filas.
                                            do{
                                                filas=JOptionPane.showInputDialog(null,"Para TABLA No."+(i+1)+"\n\nPor favor, ingrese la cantidad de filas que tendra su tabla, sin contar "
                                                    + "los atributos. \n\n","BDAAR Equipo: 4",1);
                                                R_confirmacion=JOptionPane.showInputDialog(null," Número de filas ingresadas: " +filas +" filas."
                                                + "\n\nPor favor, confirme el numero de filas que usted ingreso. \n\n","BDAAR Equipo: 4",1);
                                                if (filas.equals(R_confirmacion)){
                                                    Bandera="1";
                                                }else{
                                                    JOptionPane.showMessageDialog(null,"Las filas ingresadas en la verificación no coinciden con el primer ingreso.\n\n"
                                                    +"Ingrese los datos nuevamente.", "Error", JOptionPane.INFORMATION_MESSAGE);
                                                    Bandera="0";
                                                }
                                            }while(Bandera == "0");
                                            int numeroH = Integer.parseInt(Respuesta_Hor); //transformamos el numero de columnas a entero
                                            ArrayTamañosT[PosicionArrT]=numeroH;
                                            PosicionArrT++;
                                            int numeroV = Integer.parseInt(filas); //transformamos el numero de filas a entero
                                            ArrayTamañosT[PosicionArrT]=numeroV;
                                            PosicionArrT++;
                                            //Empieza insercion de datos
                                            //Parte para insertar los datos de la tabla i- --------------------------------------------------------
                                            //Nav.insertarDatos(numeroH,numeroV,(i+1),RNomT);
                                            int numtabla=(i+1);
                                            String respuesta="";//String de respuesta del contenido que tendra cada nodo.
                                            String Indicador_de_Salida3="1";
                                            int contAt=1;//Contador para los atributos que llevamos.
                                            double CoordenadasT=(0.0);//System.out.println(CoordenadasT);
                                            for (int j=0; j < numeroH; j++) {
                                                do
                                                {      
                                                    respuesta=JOptionPane.showInputDialog(null," Inserción de Atributos:\n\n Para el atributo: "+contAt+"   De la Tabla:  "+numtabla
                                                    + "\n\nDigite primeramente que tipo de datos contendrá dicho atributo colocando el número correspondido del siguiente menu.\n\n1.   Enteros.\n2.   Cadenas.\n3.   Flotantes.\n\n","BDAAR Equipo: 4",1);
                                                    switch(respuesta){
                                                        case "1": respuesta=JOptionPane.showInputDialog(null," \n\nAhora si, digite el nombre del atributo con el que \nidentificaremos en la tabla: \n\n","BDAAR Equipo: 4",1);
                                                                aplicar.insertar(numtabla, CoordenadasT, respuesta, 1, 0,RNomT);
                                                                String[] titulo = new String[]{respuesta};
                                                                
                                                                Indicador_de_Salida3="0";
                                                        break;
                                                        case "2": respuesta=JOptionPane.showInputDialog(null," \n\nAhora si, digite el nombre del atributo con el que \nidentificaremos en la tabla: \n\n","BDAAR Equipo: 4",1);
                                                                aplicar.insertar(numtabla, CoordenadasT, respuesta, 0, 0,RNomT);
                                                                String[] titulo2 = new String[]{respuesta};
                                                                
                                                                Indicador_de_Salida3="0";
                                                        break;
                                                        case "3": respuesta=JOptionPane.showInputDialog(null," \n\nAhora si, digite el nombre del atributo con el que \nidentificaremos en la tabla: \n\n","BDAAR Equipo: 4",1);
                                                                aplicar.insertar(numtabla, CoordenadasT, respuesta, 0, 1,RNomT);
                                                                String[] titulo3 = new String[]{respuesta};
                                                                
                                                                Indicador_de_Salida3="0";
                                                        break;
                                                    }
                                                }while(!Indicador_de_Salida3.equals("0"));

                                                CoordenadasT=(CoordenadasT+0.1);
                                                contAt++;

                                            }
                                            //System.out.println(aplicar.recorrer());---------------------------------------------------------------------No borrar, Imprimir nodos en orden.
                                            CoordenadasT=(0.0);

                                            for (int y=1; y < (numeroH+1); y++) {
                                                CoordenadasT=(((y+0.0)));
                                                for (int j=0; j < numeroV; j++) {
                                                    respuesta=JOptionPane.showInputDialog(null," Inserción de Valores:\n\n Para el valor que se encuentra en la coordenada de la Tabla:  "+CoordenadasT+"   De la Tabla:  "+numtabla
                                                    + "\n\nDigite el valor que quiera guardar, respetanto su tipo de dato.\n\n","BDAAR Equipo: 4",1);
                                                    aplicar.insertar(numtabla, CoordenadasT, respuesta, 0, 0,RNomT);
                                                    
                                                    //modelo.addRow(rowData);
                                                    CoordenadasT=(CoordenadasT+0.1);//
                                                }
                                            }
                                        }
                                            
                                        
                                        //aplicar.insertarAp(actual);//---------------------------------------------
                                        
                                    }//Fin IF CASE 1 SUBMENU
                                    
                                break;
                                case "2": //System.out.println(" Confirmacion de entrada ");//Se manda a llamar a Jtables para crear las tablas de visualizacion grafica.
                                    if("2"=="2"){
                                        setSize(750,700);
                                        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                        setLayout(null);
                                        setVisible(true);
                                    }
                                    
                                break;
                                case "3": 
                                    Indicador_de_Salida2="0";
                                break;
                            }
                        }while(!Indicador_de_Salida2.equals("0"));
                    }//FIN IF CASE 1 MENUPRINCIPAL
                    
                    
                break;
                case "2": 
                    
                break;
                case "3": 
                    Indicador_de_Salida="0";
                break;
            }
        }while(!Indicador_de_Salida.equals("0"));
        
        
        
    }
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            //BDAR Tabla = new BDAR();
            //Tabla ();
            new BDAR().setVisible(true);
        });
    }

    
    
    
}


package bdar;

import javax.swing.table.DefaultTableModel;

/**
 */
public class Lista implements ILista {
    Nodo inicioNodoTab;
    Nodo actual;
    Nodo inicio;
    Nodo fin;
    Nodo finNodoTab;
    int CantNod;
    int CantNod2;
    
    public Lista(){ 
        inicio=null;
        fin=null;
        finNodoTab=null;
        actual=null;
        inicioNodoTab=null;
        CantNod=0;
        CantNod2=0;
    }
    
    @Override
    public void insertarAp(Nodo ApuNodoInicio){
        (this.actual)=ApuNodoInicio;
        //(this.actual)=inicio;
    }
    @Override
    public void insertar(int IDTabla,double CoordT,String DatoStr,int DatoInt,float Datoflt,String RNomT) {
        
        if(CantNod==0){
            inicio=new Nodo(IDTabla,CoordT,DatoStr, DatoInt, Datoflt,RNomT,inicio);
            fin=inicio;
            actual=inicio;
            //actual=inicio;
        }else{
            fin.siguiente=new Nodo(IDTabla, CoordT, DatoStr, DatoInt, Datoflt,RNomT);
            fin = fin.siguiente;
        }
        CantNod++;
    }

    @Override
    public boolean eliminar(int IDTabla,double CoordT,String DatoStr,int DatoInt,float Datoflt,String RNomT) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int eliminar() {
        if(!vacia()){
            int dato=inicio.DatoInt;
            inicio=inicio.siguiente;
            CantNod--;
            return dato;
        }
        return -1;
    }

    @Override
    public boolean buscarIDT(int IDTabla) {
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.IDTabla==IDTabla){
                return true;
            }else{aux=aux.siguiente;}
            
        }
        return false;
    }
    @Override
    public boolean buscarCoordT (double CoordT){
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.CoordT==CoordT){
                return true;
            }else{aux=aux.siguiente;}
            
        }
        return false;
    }
    @Override
    public boolean buscarDatoStr (String DatoStr){
        Nodo aux=inicio;
        while(aux!=null){
            if((aux.DatoStr).equals(DatoStr)){
                return true;
            }else{aux=aux.siguiente;}
            
        }
        return false;
    }
    @Override
    public boolean buscarDatoInt (int DatoInt){
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.DatoInt==DatoInt){
                return true;
            }else{aux=aux.siguiente;}
            
        }
        return false;
    }
    @Override
    public boolean buscarDatoflt (float Datoflt){
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.Datoflt==Datoflt){
                return true;
            }else{aux=aux.siguiente;}
            
        }
        return false;
    }
    
    @Override
    public Nodo buscarIDTNod(int IDTabla) {
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.IDTabla==IDTabla){
                return aux;
            }else{aux=aux.siguiente;}
            
        }
        return null;
    }
    @Override
    public Nodo buscarCoordTNod (double CoordT){
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.CoordT==CoordT){
                return aux;
            }else{aux=aux.siguiente;}
            
        }
        return null;
    }
    @Override
    public Nodo buscarDatoStrNod (String DatoStr){
        Nodo aux=inicio;
        while(aux!=null){
            if((aux.DatoStr).equals(DatoStr)){
                return aux;
            }else{aux=aux.siguiente;}
            
        }
        return null;
    }
    @Override
    public Nodo buscarDatoIntNod (int DatoInt){
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.DatoInt==DatoInt){
                return aux;
            }else{aux=aux.siguiente;}
            
        }
        return null;
    }
    @Override
    public Nodo buscarDatofltNod (float Datoflt){
        Nodo aux=inicio;
        while(aux!=null){
            if(aux.Datoflt==Datoflt){
                return aux;
            }else{aux=aux.siguiente;}
            
        }
        return null;
    }
    
    @Override
    public String recorrer() {
        String Cad="{";
        Nodo aux = inicio;
        while(aux!=null){
            Cad+=aux.DatoStr+", ";
            //System.out.print(aux.DatoStr);
            aux=aux.siguiente;
        }
        return Cad + "}";
    }

    @Override
    public boolean vacia() {
        return (inicio==null)?true:false;
    }

    @Override
    public int tamaño() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
    
}
